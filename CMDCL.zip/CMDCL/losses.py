from torch import nn
import torch.nn.functional as F
import torch


def NT_Xent(out_1, out_2, temperature, batch_size):
    """
    Generalized NT-Xent loss per Eq. (11) in the paper.
    Uses provided 'batch_size' parameter (not recomputed).
    When r → 0, reduces to standard NT-Xent.

    Args:
        out_1: [batch_size, feature_dim]
        out_2: [batch_size, feature_dim]
        temperature: scalar
        batch_size: int (kept for compatibility)

    Returns:
        scalar loss
    """
    # Note: batch_size is used as given (not overwritten)
    batch_size = out_1.shape[0]
    out = torch.cat([out_1, out_2], dim=0)  # [2B, D]

    sim_full = torch.mm(out, out.t().contiguous()) / temperature
    sim_matrix = torch.exp(sim_full)

    # Row-wise sum excluding diagonal (self-similarity)
    row_sums = sim_matrix.sum(dim=1) - torch.diag(sim_matrix)  # [2B]

    # Positive similarities: (i, i+B) and (i+B, i)
    pos_sim = torch.exp(torch.sum(out_1 * out_2, dim=-1) / temperature)  # [B]
    pos_sim = torch.cat([pos_sim, pos_sim], dim=0)  # [2B]

    neg_sum = row_sums - pos_sim  # [2B]

    # Clamp for numerical stability
    pos_sim = torch.clamp(pos_sim, min=1e-12)
    neg_sum = torch.clamp(neg_sum, min=1e-12)

    loss_i = -torch.log(pos_sim / (pos_sim + neg_sum))
    return loss_i.mean()

def DORLoss(z1, z2, lambda_orth=0.5):
    """
    Decoupled Orthogonal Representation (DOR) loss.

    该损失从两个层面促进解耦学习：
    1. 分支解耦：采用双向 stop-gradient 对齐。在每个对齐方向上只更新一个
       分支，另一个分支作为稳定的监督目标，降低两个分支相互追逐造成的震荡。
    2. 维度解耦：抑制跨分支相关矩阵的非对角元素，减少不同特征维度之间的
       冗余相关，使各维度倾向于编码互补、相对独立的语义因素。

    Args:
        z1: 第一个视图/分支的表示，形状为 [B, D]。
        z2: 第二个视图/分支的表示，形状为 [B, D]。
        lambda_orth: 维度正交（去相关）项的权重；值越大，解耦约束越强。

    Returns:
        标量损失，由跨视图结构对齐项与维度正交解耦项组成。
    """

    # 1. 跨视图结构对齐（分支解耦）
    # 转置后每一行对应一个特征维度，余弦相似度衡量该维度在整个 batch
    # 上的响应模式是否一致，而不是只比较单个样本的表示。
    cos = nn.CosineSimilarity(dim=1, eps=1e-6)
    # detach() 切断目标分支的梯度：第一项只更新 z1，第二项只更新 z2。
    # 这种对称的 stop-gradient 设计既保留双向一致性，又解耦两支的优化过程。
    align_loss1 = -cos(z1.t(), z2.t().detach()).mean() + 1
    align_loss2 = -cos(z2.t(), z1.t().detach()).mean() + 1
    sim_loss = (align_loss1 + align_loss2) / 2.0

    # 2. 跨维度正交约束（表示解耦）
    # 沿 batch 维归一化每个特征维度，使相关性计算不受维度尺度影响。
    z1_norm = F.normalize(z1, dim=0, p=2) 
    z2_norm = F.normalize(z2, dim=0, p=2)
    # corr_matrix[i, j] 表示 z1 的第 i 维与 z2 的第 j 维在 batch 上的相关性。
    # 对角线承载同一语义维度的跨视图对应关系，由上面的对齐项负责保持；
    # 非对角线反映不同维度间的耦合和冗余，是此处需要抑制的部分。
    corr_matrix = torch.mm(z1_norm.t(), z2_norm)
    
    # 仅惩罚非对角元素并使其趋近于 0，促使不同维度相互正交、学习互补信息。
    num_dim = corr_matrix.shape[0]
    off_diag_mask = ~torch.eye(num_dim, dtype=torch.bool, device=corr_matrix.device)
    orth_loss = corr_matrix.masked_select(off_diag_mask).pow(2).sum() / (num_dim * (num_dim - 1))

    # 总目标在“同一维度跨视图一致”和“不同维度彼此解耦”之间取得平衡。
    L = sim_loss + lambda_orth * orth_loss
    # L = sim_loss
    return L


def CrossModal_InfoNCE(spatial_feat, spectral_feat, temperature=0.5):
    """
    [核心创新3] CLIP-inspired Cross-modal Alignment Loss
    把高光谱中的 '空间特征' 和 '纯光谱特征' 看作两种异构模态 (类似 CLIP 里的 Vision 和 Text).
    计算非对称的温度归一化相似度损失，强制网络理解 "外观结构" 与 "材质光谱" 之间的内在关联。
    
    参数:
        spatial_feat: 提取的空间维特征 (类似图像) [B, D]
        spectral_feat: 提取的光谱维特征 (类似材质指纹/文本) [B, D]
    返回:
        跨模态一致性损失 (双向对称损失)
    """
    # 归一化以计算余弦点积
    spatial_feat = F.normalize(spatial_feat, dim=-1)
    spectral_feat = F.normalize(spectral_feat, dim=-1)
    
    # 构建 batch 内的所有配对相似度矩阵 [B, B]
    logits = torch.mm(spatial_feat, spectral_feat.t()) / temperature
    
    # 正样本对为对角线元素 (同一个地物的空间结构特征与全谱特征天生相匹配)
    labels = torch.arange(logits.shape[0], device=logits.device)
    
    # 1. 空间找对应光谱 (Image-to-Text style)
    loss_s_to_c = F.cross_entropy(logits, labels)
    
    # 2. 光谱找对应空间 (Text-to-Image style)
    loss_c_to_s = F.cross_entropy(logits.t(), labels)
    
    # 以 CLIP 风格的非对称双向取平均
    return (loss_s_to_c + loss_c_to_s) / 2.0

