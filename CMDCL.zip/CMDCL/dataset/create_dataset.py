import scipy.io as sio
import numpy as np
from sklearn.decomposition import PCA
from matplotlib import pyplot as plt
import cv2
import h5py


# indian
# img = sio.loadmat('CMDCL/dataset/Indian_pines_corrected.mat')
# img = img['indian_pines_corrected']
# gt = sio.loadmat('CMDCL/dataset/Indian_pines_gt.mat')
# gt = gt['indian_pines_gt']

# paviau
# img= sio.loadmat('CMDCL/dataset/PaviaU.mat')
# img = img['paviaU']
# gt = sio.loadmat('CMDCL/dataset/PaviaU_gt.mat')
# gt = gt['paviaU_gt']

# hanchuan
# data_mat = sio.loadmat(
#     'WHU_Hi_HanChuan.mat')
# img = data_mat['WHU_Hi_HanChuan']
# gt_mat = sio.loadmat(
#     'WHU_Hi_HanChuan_gt.mat')
# gt = gt_mat['WHU_Hi_HanChuan_gt']

# salinas
# img = sio.loadmat('CMDCL/dataset/Salinas.mat')
# img = img['salinas']
# gt = sio.loadmat('CMDCL/dataset/Salinas_gt.mat')
# gt = gt['salinas_gt']

#botswana
# img = sio.loadmat('CMDCL/dataset/Botswana.mat')
# img = img['Botswana']
# gt = sio.loadmat('CMDCL/dataset/Botswana_gt.mat')
# gt = gt['Botswana_gt']

# HoustonU
# img = sio.loadmat('CMDCL/dataset/Houstondata.mat')
# img = img['Houstondata']
# gt = sio.loadmat('CMDCL/dataset/Houstonlabel.mat')
# gt = gt['Houstonlabel']

# SalinasA
# img = sio.loadmat('CMDCL/dataset/SalinasA_corrected.mat')
# img = img['salinasA_corrected']
# gt = sio.loadmat('CMDCL/dataset/SalinasA_gt.mat')
# gt = gt['salinasA_gt']

# Pavia
# img = sio.loadmat('CMDCL/dataset/Pavia.mat')
# img = img['pavia']
# gt = sio.loadmat('CMDCL/dataset/Pavia_gt.mat')
# gt = gt['pavia_gt']

# KSC
img = sio.loadmat('CMDCL/dataset/KSC.mat')['KSC']
gt = sio.loadmat('CMDCL/dataset/KSC_gt.mat')['KSC_gt']

# Yancheng
# data = sio.loadmat('data_hsi.mat')
# y1 = sio.loadmat('train_label.mat')
# y2 = sio.loadmat('test_label.mat')
# img = data['data']
# gt = y1['train_label'] + y2['test_label']

m, n, b = img.shape
num = np.bincount(gt.reshape(-1))


def Patch(data, height_index, width_index, PATCH_SIZE):
    height_slice = slice(height_index - PATCH_SIZE, height_index + PATCH_SIZE)
    width_slice = slice(width_index - PATCH_SIZE, width_index + PATCH_SIZE)
    patch = data[height_slice, width_slice, :]
    patch = patch.reshape(-1, patch.shape[0] * patch.shape[1] * patch.shape[2])
    return patch


img1 = img[:, :, :b // 2]
img2 = img[:, :, b // 2:]

img1 = img1.reshape(-1, b // 2)
img2 = img2.reshape(-1, b - b // 2)
img3 = img.reshape(-1, b)

pca = PCA(n_components=3)

reduced_img1 = pca.fit_transform(img1)
img_max, img_min = reduced_img1.max(), reduced_img1.min()
img1 = (reduced_img1 - img_min) / (img_max - img_min)
img1 = img1.reshape(m, n, 3)
# plt.figure()
# plt.imshow(img1)
# plt.show()
reduced_img2 = pca.fit_transform(img2)
img_max, img_min = reduced_img2.max(), reduced_img2.min()
img2 = (reduced_img2 - img_min) / (img_max - img_min)
img2 = img2.reshape(m, n, 3)
# plt.figure()
# plt.imshow(img2)
# plt.show()

reduced_img3 = img3
img_max, img_min = reduced_img3.max(), reduced_img3.min()
img3 = (reduced_img3 - img_min) / (img_max - img_min)
img3 = img3.reshape(m, n, b)

# PATCH_SIZE = 16
PATCH_SIZE = 14
# 在图像的边缘添加边框
img1 = cv2.copyMakeBorder(img1, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, cv2.BORDER_CONSTANT, value=(0, 0, 0))
img2 = cv2.copyMakeBorder(img2, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, cv2.BORDER_CONSTANT, value=(0, 0, 0))
img3 = cv2.copyMakeBorder(img3, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, cv2.BORDER_CONSTANT, value=(0, 0, 0))
gt = cv2.copyMakeBorder(gt, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, cv2.BORDER_CONSTANT, value=(0))

[mm, nn, bb] = img1.shape

import h5py

total_channels = b + 6
# KSC
f = h5py.File(
    'CMDCL/dataset/data/KSC-28-28-182.h5',
    'w')

# 先统计有效样本数
total_samples = int(np.sum(gt[PATCH_SIZE:mm-PATCH_SIZE, PATCH_SIZE:nn-PATCH_SIZE] > 0))
print(f'Total valid samples: {total_samples}')
data_ds = f.create_dataset('data', (total_samples, 28*28*total_channels), dtype='uint8')
label_ds = f.create_dataset('label', (total_samples,), dtype='int64')

idx = 0
for i in range(PATCH_SIZE, mm - PATCH_SIZE):
    for j in range(PATCH_SIZE, nn - PATCH_SIZE):
        if gt[i, j] == 0:
            continue
        temp_data1 = Patch(img1, i, j, PATCH_SIZE).reshape(28, 28, 3)
        temp_data2 = Patch(img2, i, j, PATCH_SIZE).reshape(28, 28, 3)
        temp_data3 = Patch(img3, i, j, PATCH_SIZE).reshape(28, 28, b)
        temp_data = np.concatenate((temp_data1, temp_data2, temp_data3), 2)
        temp_data = np.uint8(temp_data.reshape(-1) * 255)
        data_ds[idx] = temp_data
        label_ds[idx] = int(gt[i, j] - 1)
        idx += 1
        if idx % 20000 == 0:
            print(f'Progress: {idx}/{total_samples}')

# 标签重映射保护
all_labels = label_ds[:]
unique_labels = np.unique(all_labels)
label_map = {old: new for new, old in enumerate(unique_labels)}
for k in range(total_samples):
    label_ds[k] = label_map[int(label_ds[k])]

f.close()
print(f'Done! Saved {total_samples} samples.')
