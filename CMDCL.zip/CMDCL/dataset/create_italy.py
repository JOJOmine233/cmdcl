import scipy.io as sio
import numpy as np
from sklearn.decomposition import PCA
import cv2
import h5py
import os

base_dir = os.path.dirname(os.path.abspath(__file__))

# Italy dataset
img = sio.loadmat(os.path.join(base_dir, 'Italy_hsi.mat'))['data'].astype(np.float32)
gt = sio.loadmat(os.path.join(base_dir, 'allgrd.mat'))['mask_test']

m, n, b = img.shape
print(f'Image: {m}x{n}, bands={b}')
print(f'GT unique: {np.unique(gt)}')

num = np.bincount(gt.reshape(-1))
print(f'Samples per class: {num}')

def Patch(data, height_index, width_index, PATCH_SIZE):
    height_slice = slice(height_index - PATCH_SIZE, height_index + PATCH_SIZE)
    width_slice = slice(width_index - PATCH_SIZE, width_index + PATCH_SIZE)
    patch = data[height_slice, width_slice, :]
    patch = patch.reshape(-1, patch.shape[0] * patch.shape[1] * patch.shape[2])
    return patch

img1 = img[:, :, :b // 2]
img2 = img[:, :, b // 2:]

img1 = img1.reshape(-1, b // 2)
img2 = img2.reshape(-1, b - b // 2)
img3 = img.reshape(-1, b)

pca = PCA(n_components=3)

reduced_img1 = pca.fit_transform(img1)
img_max, img_min = reduced_img1.max(), reduced_img1.min()
img1 = (reduced_img1 - img_min) / (img_max - img_min)
img1 = img1.reshape(m, n, 3)

reduced_img2 = pca.fit_transform(img2)
img_max, img_min = reduced_img2.max(), reduced_img2.min()
img2 = (reduced_img2 - img_min) / (img_max - img_min)
img2 = img2.reshape(m, n, 3)

reduced_img3 = img3
img_max, img_min = reduced_img3.max(), reduced_img3.min()
img3 = (reduced_img3 - img_min) / (img_max - img_min)
img3 = img3.reshape(m, n, b)

PATCH_SIZE = 14
img1 = cv2.copyMakeBorder(img1, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, cv2.BORDER_CONSTANT, value=(0, 0, 0))
img2 = cv2.copyMakeBorder(img2, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, cv2.BORDER_CONSTANT, value=(0, 0, 0))
img3 = cv2.copyMakeBorder(img3, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, cv2.BORDER_CONSTANT, value=(0, 0, 0))
gt = cv2.copyMakeBorder(gt, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, PATCH_SIZE, cv2.BORDER_CONSTANT, value=(0))

[mm, nn, bb] = img1.shape
total_channels = b + 6

total_samples = int(np.sum(gt[PATCH_SIZE:mm-PATCH_SIZE, PATCH_SIZE:nn-PATCH_SIZE] > 0))
print(f'Total valid samples: {total_samples}')

f = h5py.File(os.path.join(base_dir, 'data', 'Italy-28-28-69.h5'), 'w')
data_ds = f.create_dataset('data', (total_samples, 28*28*total_channels), dtype='uint8')
label_ds = f.create_dataset('label', (total_samples,), dtype='int64')

idx = 0
for i in range(PATCH_SIZE, mm - PATCH_SIZE):
    for j in range(PATCH_SIZE, nn - PATCH_SIZE):
        if gt[i, j] == 0:
            continue
        temp_data1 = Patch(img1, i, j, PATCH_SIZE).reshape(28, 28, 3)
        temp_data2 = Patch(img2, i, j, PATCH_SIZE).reshape(28, 28, 3)
        temp_data3 = Patch(img3, i, j, PATCH_SIZE).reshape(28, 28, b)
        temp_data = np.concatenate((temp_data1, temp_data2, temp_data3), 2)
        temp_data = np.uint8(temp_data.reshape(-1) * 255)
        data_ds[idx] = temp_data
        label_ds[idx] = int(gt[i, j] - 1)
        idx += 1
        if idx % 10000 == 0:
            print(f'Progress: {idx}/{total_samples}')

print(f'Done! Total saved: {idx}')
print(f'Labels: {sorted(set(f["label"][:]))}')
f.close()
