import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.layers import trunc_normal_, DropPath

class LayerNorm(nn.Module):
    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_last"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise NotImplementedError 
        self.normalized_shape = (normalized_shape, )
    
    def forward(self, x):
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x

class Block(nn.Module):
    def __init__(self, dim, drop_path=0., layer_scale_init_value=1e-6, is_1x1=False):
        super().__init__()
        # 如果是1x1输入，padding使用0，且kernel设置为1以防报错
        k_size = 1 if is_1x1 else 7
        pad_size = 0 if is_1x1 else 3
        self.dwconv = nn.Conv2d(dim, dim, kernel_size=k_size, padding=pad_size, groups=dim) 
        self.norm = LayerNorm(dim, eps=1e-6) 
        self.pwconv1 = nn.Linear(dim, 4 * dim) 
        self.act = nn.GELU()
        self.pwconv2 = nn.Linear(4 * dim, dim)
        self.gamma = nn.Parameter(layer_scale_init_value * torch.ones((dim)),
                                    requires_grad=True) if layer_scale_init_value > 0 else None
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x):
        input = x 
        x = self.dwconv(x)
        x = x.permute(0, 2, 3, 1) 
        x = self.norm(x)
        x = self.pwconv1(x)
        x = self.act(x)
        x = self.pwconv2(x)
        if self.gamma is not None:
            x = self.gamma * x
        x = x.permute(0, 3, 1, 2) 

        x = input + self.drop_path(x)
        return x

class ConvNeXt(nn.Module):
    def __init__(self, in_chans=3, num_classes=1000, 
                 depths=[3, 3, 9, 3], dims=[96, 192, 384, 768], drop_path_rate=0., 
                 layer_scale_init_value=1e-6, head_init_scale=1., is_1x1=False
                 ):
        super().__init__()
        self.downsample_layers = nn.ModuleList() 
        
        # 如果是1x1输入，stride和kernel_size不能大于1
        stem_kernel = 1 if is_1x1 else 2
        stem_stride = 1 if is_1x1 else 2
        
        stem = nn.Sequential(
            nn.Conv2d(in_chans, dims[0], kernel_size=stem_kernel, stride=stem_stride),
            LayerNorm(dims[0], eps=1e-6, data_format="channels_first")
        )
        self.downsample_layers.append(stem)
        
        for i in range(3):
            ds_kernel = 1 if is_1x1 else 2
            ds_stride = 1 if is_1x1 else 2
            downsample_layer = nn.Sequential(
                    LayerNorm(dims[i], eps=1e-6, data_format="channels_first"),
                    nn.Conv2d(dims[i], dims[i+1], kernel_size=ds_kernel, stride=ds_stride),
            )
            self.downsample_layers.append(downsample_layer)
            
        self.stages = nn.ModuleList() 
        dp_rates=[x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]
        cur = 0
        for i in range(4):
            stage = nn.Sequential(
                *[Block(dim=dims[i], drop_path=dp_rates[cur + j], 
                layer_scale_init_value=layer_scale_init_value, is_1x1=is_1x1) for j in range(depths[i])]
            )
            self.stages.append(stage)
            cur += depths[i]

        self.feature_dim = dims[-1]
        self.norm = nn.LayerNorm(dims[-1], eps=1e-6)

    def _init_weights(self, m):
        if isinstance(m, (nn.Conv2d, nn.Linear)):
            trunc_normal_(m.weight, std=.02)
            nn.init.constant_(m.bias, 0)

    def forward_features(self, x):
        for i in range(4):
            x = self.downsample_layers[i](x)
            x = self.stages[i](x)
        return self.norm(x.mean([-2, -1]))

    def forward(self, x):
        x = self.forward_features(x)
        return x

class CMDCL_ConvNeXt(nn.Module):
    def __init__(self, in_chans, feature_dim, is_1x1=False):
        super().__init__()
        self.is_1x1 = is_1x1
        self.backbone = ConvNeXt(in_chans=in_chans, depths=[3, 3, 9, 3], dims=[96, 192, 384, 768], is_1x1=is_1x1)
        self.fc = nn.Linear(768, feature_dim)
        self.p = nn.Linear(feature_dim, feature_dim)
        self.relu = nn.ReLU()
    
    def forward(self, x):
        if len(x.shape) == 2:
            x = x.unsqueeze(-1).unsqueeze(-1)
            
        x = self.backbone(x)
        output = self.fc(x)
        out = self.p(self.relu(output))
        return F.normalize(output, dim=-1), F.normalize(out, dim=-1)
