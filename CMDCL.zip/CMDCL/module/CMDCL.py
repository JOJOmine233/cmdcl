import torch
import torch.nn as nn
from torch.nn import Parameter
import torch.nn.functional as F
from .convnext import CMDCL_ConvNeXt

class CMDCL(nn.Module):
    def __init__(self, feature_dim, b, device, args):
        super(CMDCL, self).__init__()
        self.n_anchors = args.anchors
        # 注释掉的编码器1：ResNet34，用于特征提取
        # self.encoder1 = ResNet34(device, num_classes)
        # 注释掉的编码器2：LSTM，用于处理时序数据
        # self.encoder2 = LSTM(3, num_classes, b)
        # 编码器3：ConvNeXt，用于提取输入数据的特征
        self.encoder3 = CMDCL_ConvNeXt(in_chans=3, feature_dim=feature_dim, is_1x1=False)
        # 编码器4：ConvNeXt，用于处理位置数据/光谱数据
        self.encoder4 = CMDCL_ConvNeXt(in_chans=b, feature_dim=feature_dim, is_1x1=True)

        # 可学习参数矩阵，用于特征变换
        self.weight = Parameter(torch.FloatTensor(128, 128), requires_grad=True)
        # 使用Xavier均匀分布初始化权重
        torch.nn.init.xavier_uniform_(self.weight)
        # 激活函数：Tanh
        self.act = nn.Tanh()
        # 设备信息
        self.device = device
        # Sigmoid激活函数
        self.s = nn.Sigmoid()
        # 锚点中心，用于聚类
        self.anchor_centers = Parameter(torch.Tensor(args.anchors, args.embedding), requires_grad=True)

    def update_anchors(self, data):
        """
        更新锚点中心的函数
        参数:
            data: 输入数据
        """
        # 计算数据与锚点中心的相似度，并进行归一化
        sim = F.normalize(torch.mm(data, self.anchor_centers.t()), dim=-1)
        # 使用softmax获取概率，并找到最相似的锚点索引
        label = sim.softmax(dim=1).argmax(dim=1, keepdim=True).reshape(-1)
        # 更新每个锚点中心
        for i in range(self.n_anchors):
            # 找到属于当前锚点的数据点
            indices = label == i
            if indices.sum() > 0:
                # 将锚点中心更新为属于该锚点的数据点的均值
                self.anchor_centers[i].data = torch.mean(data[indices], dim=0)

    def forward(self, input, pot):
        # a
        # feature1, out1 = self.encoder1(input)
        # feature2, out2 = self.encoder2(pot)

        # b
        feature3, out3 = self.encoder3(input)
        feature4, out4 = self.encoder4(pot)

        # fusion
        # feature_a, out_a = (feature1 + feature2) / 2, (out1 + out2) / 2
        feature_b, out_b = (feature3 + feature4) * 1e2 / 2, (out3 + out4) / 2

        # [核心创新3]为了支持跨模态比齐（CLIP化），我们将原本独立融合的空间分支(out3)和光谱分支(out4)提取出给外面的损失函数计算距离
        return feature_b, out_b, out3, out4
